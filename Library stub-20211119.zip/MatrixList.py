#!/usr/bin/env python3

from __future__ import annotations
from typing import List, Union, Tuple, overload

class Matrix:
    """
    A list-based implementation of a simple row-major dense matrix with 64-bit
    floating-point elements.
    """
    _rows: int
    _cols: int
    _data: List[float]
    _first_idx: int
    _stride: int

    def __init__(self, rows: int = 0, cols: int = 0,
                     data: List[float] = None, 
                     row_length: int = None, first_idx: int = None):
        """
        Constructor for constructing a submatrix given the information of its 
        shape and location in the supermatrix.

        Leaving the later arguments out results in a regular 
        zero-initialized matrix.
        """
        self._rows = rows
        self._cols = cols
        self._data = [0.0] * (self._cols*self._rows) if data is None else data
        self._stride = cols if row_length is None else row_length
        self._first_idx = 0 if first_idx is None else first_idx

        
        
    def rows(self)->int:
        """
        Returns the number of rows in the matrix
        """
        return self._rows


    
    def cols(self)->int:
        """
        Returns the number of columns in the matrix
        """
        return self._cols



    @classmethod
    def from_list(cls, data: List[List[float]])->Matrix:
        """
        Construct a matrix from a list of lists
        """
        rows = len(data)
        cols = len(data[0])
        A = Matrix(rows,cols)
        k = 0
        for i in range(rows):
            for j in range(cols):
                 A._data[k] = data[i][j]
                 k += 1
        return A



    # these overloads help mypy determine the correct types
    @overload
    def __getitem__(self, key: int)->float: ...

    @overload
    def __getitem__(self, key: Tuple[slice,slice])->Matrix: ...
        
    @overload
    def __getitem__(self, key: Tuple[int,int])->float: ...


    def __getitem__(self, key: Union[int,Tuple[int,int],slice,Tuple[int,slice], Tuple[slice,int], Tuple[slice,slice]])->Union[float,Matrix]:
        """
        Implements the operator A[i,j] supporting also slices for submatrix 
        access.

        Note however that the slice support is only partial: the step value is 
        ignored.
        """
        if isinstance(key,int):
            return self._data[self._first_idx + (key//self._cols)*self._stride + key % self._cols]
        if isinstance(key,slice):
            stop = key.stop if key.stop is not None else self._rows
            start = key.start if key.start is not None else 0
            return Matrix(stop - start,
                              self._cols,
                              self._data,
                              self._stride,
                              self._first_idx + self._stride*start)
        assert isinstance(key,tuple)
        if isinstance(key[0],int) and isinstance(key[1],int):
            i: int = key[0]
            j: int = key[1]
            return self._data[self._first_idx + i*self._stride + j]
        row_stop: int
        row_start: int
        col_stop: int
        col_start: int
        if isinstance(key[0], slice):
            row_stop = self._rows if key[0].stop is None else key[0].stop
            row_start = 0 if key[0].start is None else key[0].start
        else:
            row_stop = key[0] + 1
            row_start = key[0]
        if isinstance(key[1],slice):
            col_stop = self._cols if key[1].stop is None else key[1].stop
            col_start = 0 if key[1].start is None else key[1].start
        else:
            col_stop = key[1]+1
            col_start = key[1]
        return Matrix(row_stop - row_start,
                          col_stop - col_start,
                          self._data,
                          self._stride,
                          self._first_idx + self._stride*row_start + col_start)

    
    def __eq__(self, that: object)->bool:
        """
        Implements the operator ==
        Returns true if and only if the two matrices agree in shape and every
        corresponding element compares equal.
        """
        if not isinstance(that, Matrix):
            return NotImplemented
        
        if self._rows != that._rows:
            return False
        if self._cols != that._cols:
            return False
        for i in range(self._rows):
            for j in range(self._cols):
                if self[i,j] != that[i,j]:
                    return False
        return True


    
    def __str__(self)->str:
        """
        Returns a human-readable representation of the matrix
        """
        return '\n'.join([' '.join([str(self[i,j])
                                        for j in range(self._cols)])
                              for i in range(self._rows)])


    def tolist(self)->List[List[float]]:
        """
        Returns a list-of-list representation of the matrix
        """
        A: List[List[float]] = list()
        for i in range(self._rows):
            B: List[float] = list()
            for j in range(self._cols):
                c = self[i,j]
                assert isinstance(c,float)
                B.append(c)
            A.append(B)
        return A


    def __setitem__(self, key: Union[int,Tuple[int,int]], value: float)->None:
        """
        Implements the assignment operator A[i,j] = v supporting also 
        one-dimensional flat access.

        Slices are *not* supported.
        """
        if isinstance(key,int):
            self._data[self._first_idx + (key//self._cols)*self._stride + 
                           (key%self._cols)] = float(value)
        else:
            assert isinstance(key,tuple)
            i: int
            j: int
            i, j = key
            assert 0 <= i < self._rows
            assert 0 <= j < self._cols
            self._data[self._first_idx + i*self._stride + j] = float(value)


            
    def __add__(self, that: Matrix)->Matrix:
        """
        Regular addition of two matrices. Does not modify the operands.
        """
        raise NotImplementedError('Fill in the implementation')


    def __iadd__(self, that: Matrix)->Matrix:
        """
        In-place addition of two matrices, modifies the left-hand side operand.
        """
        raise NotImplementedError('Fill in the implementation')



    def __sub__(self, that: Matrix)->Matrix:
        """
        Regular subtraction of two matrices. Does not modify the operands.
        """
        raise NotImplementedError('Fill in the implementation')



    def __isub__(self, that: Matrix)->Matrix:
        """
        Regular subtraction of two matrices. Does not modify the operands.
        """
        raise NotImplementedError('Fill in the implementation')



def elementary_multiplication(A: Matrix, B: Matrix)->Matrix:
    """
    Compute C = AB with three nested loops
    """
    raise NotImplementedError('Fill in the implementation')



def transpose(A: Matrix)->None:
    """
    Transposes the matrix in-place
    """
    raise NotImplementedError('Fill in the implementation')



def elementary_multiplication_transposed(A: Matrix, B: Matrix)->Matrix:
    """
    Compute C = AB with three nested loops, assuming transposed B
    """
    raise NotImplementedError('Fill in the implementation')



def tiled_multiplication(A: Matrix, B: Matrix, s: int)->Matrix:
    """
    Computes C=AB using (n/s)^3 multiplications of size s*s
    """
    raise NotImplementedError('Fill in the implementation')



def elementary_multiplication_in_place(C: Matrix, A: Matrix, B: Matrix)->None:
    """
    An auxiliary function that computes elementary matrix
    multiplication in place, that is, the operation is C += AB such
    that the product of AB is added to matrix C.
    """
    raise NotImplementedError('Fill in the implementation')



def recursive_multiplication_write_through(A: Matrix, B: Matrix, m: int)->Matrix:
    """
    Computes C=AB recursively using a write-through strategy. That
    is, no intermediate copies are created; the matrix C is
    initialized as the function is first called, and all updates
    are done in-place in the recursive calls.
     
    The parameter m controls such that when the subproblem size
    satisfies n <= m, * an iterative cubic algorithm is called instead.
    """
    raise NotImplementedError('Fill in the implementation')



def recursive_multiplication_copying(A: Matrix, B: Matrix)->Matrix:
    """
    Computes C=AB by explicitly writing all intermediate
    results. That is, we define the following matrices in terms of
    the operand block matrices:
    
    P0 = A00
    P1 = A01
    P2 = A00
    P3 = A01
    P4 = A10
    P5 = A11
    P6 = A10
    P7 = A11
    Q0 = B00
    Q1 = B10
    Q2 = B01
    Q3 = B11
    Q4 = B00
    Q5 = B10
    Q6 = B01
    Q7 = B11
     
    Then compute Mi = Pi*Qi by a recursive application of the function
  
    Followed by the integration
    C00 = M0 + M1
    C01 = M2 + M3
    C10 = M4 + M5
    C11 = M6 + M7
    """
    raise NotImplementedError('Fill in the implementation')



def strassen(A: Matrix, B: Matrix, m: int)->Matrix:
    """
    Computes C=AB using Strassen's algorithm. The structure ought
    to be similar to the copying recursive algorithm. The parameter
    m controls when the routine falls back to a cubic algorithm, as
    the subproblem size satisfies n <= m.
    """
    raise NotImplementedError('Fill in the implementation')
